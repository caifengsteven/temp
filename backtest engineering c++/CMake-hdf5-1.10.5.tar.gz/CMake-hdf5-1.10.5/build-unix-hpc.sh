ctest -S HDF5config.cmake,HPC=sbatch,MPI=true -C Release -V -O hdf5.log
